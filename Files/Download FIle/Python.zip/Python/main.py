# START of CODE

# Required imports
import time
import pywhatkit
import pyautogui

from termcolor import colored
from datetime import date
from datetime import datetime


# Tracking the Parking Spaces
car_parking = ['Available !!!', 'Available !!!', 'Available !!!']
bike_parking = ['Available !!!', 'Available !!!', 'Available !!!', 'Available !!!', 'Available !!!']

# Main Code
while True:
    print("\n"*50)

    # Finding out whether the user wants to exit/park
    print("-------------------------------------------------------------------------")
    print("-------------------------------------------------------------------------")
    print('Hello and welcome to "Pick The Spot (PTS)" Parking !\n')

    UI_1 = input("""Type '1' if you would like to park your car (₹50).
Type '2' if you would like to park your two wheeler (₹30).
Type '3' if you would like to exit the parking space.
> """)
    print("-------------------------------------------------------------------------")

# Checking and assigning a Parking Space
    if UI_1 == '1':
        for i in car_parking:
            if i == 'Available !!!':

                print("          ", "Great, parking spaces are ", i)
                print("-------------------------------------------------------------------------")

                z = (car_parking.index(i))
                sum = z + 1

                if sum == 1:

                    Name_1 = input("Enter your name : ")
                    Number_1 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_1_1 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_1_1 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'c'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_1_1, "at", Time_1_1)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_1, """Thank You for using PTS Parking !
Your parking space code is *1c*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                elif sum == 2:

                    Name_2 = input("Enter your name : ")
                    Number_2 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_1_2 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_1_2 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'c'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_1_2, "at", Time_1_2)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_2, """Thank You for using PTS Parking !
Your parking space code is *2c*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                elif sum == 3:

                    Name_3 = input("Enter your name : ")
                    Number_3 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_1_3 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_1_3 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'c'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_1_3, "at", Time_1_3)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_3, """Thank You for using PTS Parking !
Your parking space code is *3c*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                else:
                    break

                car_parking[z] = 'false'

                time.sleep(5)
                print("\n"*50)

                break
        else:
            print("         ", "Sorry! All parking spaces are currently occupied :(")

            time.sleep(5)
            print("\n"*50)

    elif UI_1 == '2':
        for i in bike_parking:
            if i == 'Available !!!':

                print("          ", "Great, parking spaces are ", i)
                print("-------------------------------------------------------------------------")

                z = (bike_parking.index(i))
                sum = z + 1

                if sum == 1:
                    Name_4 = input("Enter your name : ")
                    Number_4 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_2_1 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_2_1 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'b'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_2_1, "at", Time_2_1)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_4, """Thank You for using PTS Parking !
Your parking space code is *1b*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                elif sum == 2:
                    Name_5 = input("Enter your name : ")
                    Number_5 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_2_2 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_2_2 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'b'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_2_2, "at", Time_2_2)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_5, """Thank You for using PTS Parking !
Your parking space code is *2b*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                elif sum == 3:
                    Name_6 = input("Enter your name : ")
                    Number_6 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_2_3 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_2_3 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'b'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_2_3, "at", Time_2_3)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_6, """Thank You for using PTS Parking !
Your parking space code is *3b*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                elif sum == 4:
                    Name_7 = input("Enter your name : ")
                    Number_7 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_2_4 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_2_4 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'b'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_2_4, "at", Time_2_4)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_7, """Thank You for using PTS Parking !
Your parking space code is *4b*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                elif sum == 5:
                    Name_8 = input("Enter your name : ")
                    Number_8 = input("Enter your phone number with the country code : ")
                    print("-------------------------------------------------------------------------")

                    today = date.today()
                    Date_2_5 = today.strftime("%B %d, %Y")

                    now = datetime.now()
                    Time_2_5 = now.strftime("%H:%M:%S")

                    print("                   ", "You can park at", colored((str(sum) + 'b'), 'cyan', attrs=['reverse', 'blink']))
                    print("     ", "Note, you parked on", Date_2_5, "at", Time_2_5)
                    print("You will receive a msg with the parking code for your convenience :)")
                    print("                      ", "Thank You !")

                    time.sleep(3)

                    pywhatkit.sendwhatmsg_instantly(Number_8, """Thank You for using PTS Parking !
Your parking space code is *5b*.""")
                    pyautogui.click(800, 720)
                    pyautogui.press("enter")
                    time.sleep(3)
                    pyautogui.keyDown('ctrl')
                    pyautogui.press('w')
                    pyautogui.keyUp('ctrl')

                else:
                    break

                bike_parking[z] = 'false'

                time.sleep(5)
                print("\n"*50)

                break
        else:
            print("         ", "Sorry! All parking spaces are currently occupied :(")

            time.sleep(5)
            print("\n"*50)

# Emptying the parking spaces on exit

    elif UI_1 == '3':
        UI_2 = input("Enter your parking space code : ")
        print("-------------------------------------------------------------------------")

        if UI_2 == '1c':
            if car_parking[0] == 'false':

                today = date.today()
                Date_3 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_3 = now.strftime("%H:%M:%S")

                car_parking[0] = 'Available !!!'

                print("     ", "Okay, you exited on", Date_3, "at", Time_3)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_1))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_1, """The amount to be paid is ₹50/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '2c':
            if car_parking[1] == 'false':

                today = date.today()
                Date_4 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_4 = now.strftime("%H:%M:%S")

                car_parking[1] = 'Available !!!'

                print("     ", "Okay, you exited on", Date_4, "at", Time_4)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_2))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_2, """The amount to be paid is ₹50/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '3c':
            if car_parking[2] == 'false':

                today = date.today()
                Date_5 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_5 = now.strftime("%H:%M:%S")

                car_parking[2] = 'Available !!!'

                print("     ", "Okay, you exited on", Date_5, "at", Time_5)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_3))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_3, """The amount to be paid is ₹50/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '1b':
            if bike_parking[0] == 'false':

                today = date.today()
                Date_6 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_6 = now.strftime("%H:%M:%S")

                bike_parking[0] = 'Available !!!'

                print("    ", "Okay, you exited on", Date_6, "at", Time_6)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_4))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_4, """The amount to be paid is ₹30/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '2b':
            if bike_parking[1] == 'false':

                today = date.today()
                Date_7 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_7 = now.strftime("%H:%M:%S")

                bike_parking[1] = 'Available !!!'

                print("    ", "Okay, you exited on", Date_7, "at", Time_7)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_5))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_5, """The amount to be paid is ₹30/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '3b':
            if bike_parking[2] == 'false':

                today = date.today()
                Date_8 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_8 = now.strftime("%H:%M:%S")

                bike_parking[2] = 'Available !!!'

                print("    ", "Okay, you exited on", Date_8, "at", Time_8)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_5))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_6, """The amount to be paid is ₹30/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '4b':
            if bike_parking[2] == 'false':

                today = date.today()
                Date_9 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_9 = now.strftime("%H:%M:%S")

                bike_parking[3] = 'Available !!!'

                print("    ", "Okay, you exited on", Date_9, "at", Time_9)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_6))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_7, """The amount to be paid is ₹30/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        elif UI_2 == '5b':
            if bike_parking[2] == 'false':

                today = date.today()
                Date_10 = today.strftime("%B %d, %Y")

                now = datetime.now()
                Time_10 = now.strftime("%H:%M:%S")

                bike_parking[4] = 'Available !!!'

                print("    ", "Okay, you exited on", Date_10, "at", Time_10)
                print("    ", "You will receive a msg with the amount to be paid"".")
                print("         ", "Thank You for using PTS Parking {} !!!".format(Name_7))
                time.sleep(3)

                pywhatkit.sendwhatmsg_instantly(Number_8, """The amount to be paid is ₹30/-
Thank You for using PTS Parking !
Have a great day !""")
                pyautogui.click(800, 720)
                pyautogui.press("enter")
                time.sleep(3)
                pyautogui.keyDown('ctrl')
                pyautogui.press('w')
                pyautogui.keyUp('ctrl')

                time.sleep(5)
                print("\n"*50)

            else:
                print("Sorry ! The Parking Space code entered is wrong !")

                time.sleep(5)
                print("\n"*50)

        else:
            print("Sorry ! The Parking Space code entered is wrong !")

            time.sleep(5)
            print("\n"*50)
    else:
        print("Invalid Input detected, please try again !")

        time.sleep(0)
        print("\n"*50)

# END of CODE
